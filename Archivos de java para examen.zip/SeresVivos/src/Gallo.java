
public class Gallo extends Ave {
    public Gallo(){
        super();
    }
    public Gallo(String tipo){
        super.setTipo(tipo);
    }
    @Override
    public void vuela(){
        super.vuela();
    }
}
