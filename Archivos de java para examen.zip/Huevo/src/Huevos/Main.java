package Huevos;
import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.print("Introduzca el n�mero de huevos");	
		int nCasillas= sc.nextInt();
		
		Huevo PaqueteDeHuevos[]=new Huevo[nCasillas];
		for(int i=0;i<nCasillas;i++) {
			PaqueteDeHuevos[i]=new Huevo();
			
			System.out.print(PaqueteDeHuevos[i].toString());
			
		}
		PaqueteDeHuevos[i]=
	}

}
